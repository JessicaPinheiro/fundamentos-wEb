-- Undertale DEMO v1.00 --

-- Please open instruction.html for more credits and information about the game. --

-- Note: The game can be played one-handed or on European keyboards with the following keys: --

ENTER = Z
SHIFT = X
CTRL = C


FONTS --

-- Main font - 8Bitoperator by Jayvee D. Enaguas (Grand Chaos) --
-- Damage font - Hachicro by FluckyFrog --
-- Various bitmap fonts by auntie pixelante --
-- Special thanks to Flashygoodness for the keyboard code. --

NOTE: The DEMO is made with Game Maker 8, while the full game is made with Game Maker Studio. This DEMO is provided purely for legacy purposes and is not an accurate depiction of whether the game will work on your computer or not.